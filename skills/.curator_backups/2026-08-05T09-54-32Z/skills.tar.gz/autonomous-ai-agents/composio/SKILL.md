---
name: composio
description: Composio CLI setup, install, OAuth login link, connect apps.
---

# Composio CLI setup, login & connections

Composio gives agents tool access to third-party apps (Gmail, GitHub, Slack, …) with hosted OAuth. The CLI has TWO generations — know which one you're on:

| | Legacy (dead) | New (current) |
|---|---|---|
| Install | `pip install composio-core` | `curl -fsSL https://composio.dev/install \| bash` |
| Version | 0.7.21 (PyPI frozen here — no newer pip release) | 0.3.x compiled binary |
| Binary | venv script, e.g. `~/.venvs/composio/bin/composio` | `~/.composio/composio` (installer puts `~/.composio` first on PATH) |
| Backend | `backend.composio.dev/api/v1/*` — **decommissioned** | v3 APIs |

## Install (headless server)

```bash
# Inspect first, then run — it's a GitHub-release downloader with checksum verify
curl -fsSL https://composio.dev/install -o /tmp/composio_install.sh
bash /tmp/composio_install.sh --no-plugins   # --no-plugins skips Claude Code plugin probing
```

## Login (the OAuth link flow)

1. `composio login --no-wait --no-skill-install` → prints a one-time URL:
   `https://dashboard.composio.dev/?cliKey=<uuid>` (valid ~10 min)
2. Send that URL to the user to open in their browser and authorize.
3. Start `composio login --poll` (background + notify_on_complete) so login completes automatically the moment the user clicks. Do NOT ask the user whether to poll — they already requested login.
4. Verify: `composio whoami` (empty output = not logged in).
5. Alternative for unattended agents: `composio login --agent` (creates a Composio agent account, no browser).

## Connect app accounts

- `composio link <app>` → generates a **Connect Link** like `https://connect.composio.dev/link/ln_abc123` that the user opens to authorize the app. Credentials never pass through your machine.
- `composio search "<natural language>"` — find tools; `composio execute <TOOL_SLUG> -d '{...}'` — run a tool; `composio proxy <provider-url> --toolkit <tk>` — call a provider API with Composio-managed auth.

## Pitfalls

1. **Legacy v1 backend is gone.** Any request to `backend.composio.dev/api/v1/*` returns `HTTP 410 "This endpoint is no longer available. Please upgrade to v3 APIs."` — including old-CLI API-key validation and `composio login`. The old pip CLI is unusable, period; install the binary CLI instead. See `references/legacy-v1-to-v3-migration.md`.
2. **410 is endpoint-wide, not key-specific.** Before blaming the API key, probe: `curl -s -o /dev/null -w '%{http_code}' https://backend.composio.dev/api/v1/client/auth/client_info` with no key / garbage key — if those also 410, the endpoint (not the key) is dead.
3. **PyPI has no upgrade path.** `composio-core` is frozen at 0.7.21; `pip install -U` changes nothing.
4. **Stale `COMPOSIO_API_KEY` env var** may hold a dead legacy key. `unset COMPOSIO_API_KEY` before running the new CLI (the new CLI ignores it, but it can shadow/confuse state checks).
5. Old CLI's `composio --help` crashes with a traceback (click help-format bug) — don't use it for command discovery; use `composio <cmd> --help` or just upgrade.
6. Docs moved: `docs.composio.dev/cli/*` is 404 → use `docs.composio.dev/docs/*` (cli, authentication, migration-guide). Plain `curl -sL` works on the docs (web tools may be down); strip tags with python/regex to read them.

## Verification checklist

- [ ] `~/.composio/composio --version` reports 0.3.x
- [ ] `composio whoami` shows a session (not empty)
- [ ] `composio link <app>` yields a `connect.composio.dev/link/...` URL
