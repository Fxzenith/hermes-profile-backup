---
name: composio-cli
description: "Configure Composio: install CLI, OAuth login, link apps."
---

# Composio CLI

Composio is an AI-agent tool-integration platform: OAuth connections for apps (Gmail, GitHub, Instagram, X/Twitter, Slack…) exposed as tools an agent can execute. The CLI is the agent's local tool surface: connect apps, execute tools, proxy authenticated APIs.

## Install (v3 CLI — the ONLY current one)

```bash
curl -fsSL https://composio.dev/install | bash   # installs to ~/.composio/composio
export PATH="$HOME/.composio:$PATH"              # installer also appends to ~/.bashrc
composio --version                               # expect 0.3.x (v3)
```

- Installs a large (~120MB) self-contained `@composio/cli` binary.
- After install, `which composio` MUST resolve to `~/.composio/composio`. Any older `composio` symlink earlier in PATH (e.g. `~/.local/bin/composio` left by a previous pip install) shadows it — delete the stale symlink and re-check.

## Login — give the user an OAuth link

```bash
composio login --no-wait          # prints https://dashboard.composio.dev/?cliKey=<uuid> — send this URL to the user (valid ~10 min)
composio login --poll             # run in background; completes automatically once the user clicks the URL
```

- No human available: `composio login --agent` signs in with a Composio agent account, no browser.
- `--no-skill-install` skips auto-installing the composio-cli skill into Claude Code.
- Login state lives in `~/.composio/` (config.json / user_data.json). `"api_key": null` in user_data.json = never logged in.

## Connect apps & run tools

```bash
composio link <app>                     # OAuth-connect an account (gmail, instagram, twitter, github…)
composio search "<natural language>"    # find tools
composio execute <TOOL> --get-schema    # inspect schema
composio execute <TOOL> -d '{...}'      # run a tool
composio proxy <provider-url> --toolkit <app>   # call provider API with Composio-managed auth
composio run '<inline TS>'              # multi-step scripted workflow (execute/search/proxy injected)
composio connections                    # list connected accounts (v3 CLI name; legacy CLI used `connected-accounts`)
```

## Pitfalls (all hit in practice — see references/pitfalls.md for transcripts)

1. **PyPI `composio-core` is the LEGACY v2 SDK** (0.7.x, as of mid-2026). Its CLI hits deprecated endpoints: `composio login` fails with `{"error":"This endpoint is no longer available. Please upgrade to v3 APIs."}` and API-key validation returns **HTTP 410 Gone**. Do not install it for CLI use.
2. **npm `composio` (1.0.0) is a "hello world" stub** — 114-byte index.js, no binary in package.json. Not the real CLI.
3. **A stale `COMPOSIO_API_KEY` env var poisons the CLI** — it gets picked up and validated against dead endpoints, and `composio login` warns about it. `composio whoami` echoes the key; never paste it into chat.
4. **Docs site (docs.composio.dev) is client-rendered**: plain curl returns nav-only HTML. Append `.md` to any docs URL (Mintlify) to get raw Markdown: `curl https://docs.composio.dev/docs/cli.md`.
