---
name: yellosa-cdp-scrape
description: Scrape Yellosa business leads via Chrome DevTools Protocol.
---

# Yellosa CDP Scraper

Scrape Yellosa business profiles via the **Chrome DevTools Protocol** (puppeteer-core driving the
system Chromium). Real DOM navigation + clicks — required because the site lazy-loads content
(contacts, Q&A) client-side and blocks naive `curl`/fetch on detail fields.

## When to use
- User says "get businesses from Yellosa", "scrape Yellosa <city>", "pull leads from yellosa.co.za".
- Target site is yellosa.co.za specifically (URL structure below is site-specific).

## Environment check (run first)
Chromium is usually present via snap on this box. Verify before installing anything:
```bash
ls /snap/chromium/current/usr/lib/chromium-browser/chrome 2>/dev/null && echo HAVE_CHROME || echo NO_CHROME
which node npm 2>/dev/null
node -e "require('puppeteer-core'); console.log('have puppeteer-core')" 2>/dev/null || echo NEED_PUPPETEER
```
- If NO_CHROME: install chromium (snap install chromium) or set `executablePath` to any Chrome/Chromium.
- If NEED_PUPPETEER: `npm init -y && npm install puppeteer-core` (uses existing browser — NO browser download, unlike full `puppeteer`).

## URL structure (discovered — do not guess)
- City listings:  `https://yellosa.co.za/location/<city>`  (e.g. /location/pretoria)
- Pagination:     `https://yellosa.co.za/location/<city>?page=N`  (N starts at 2)
- Company profile:`https://yellosa.co.za/company/<id>/<slug>`  (links found as `a[href*="/company/"]` with `/\/company\/\d+\//`)
- Q&A page:       `https://yellosa.co.za/question/<id>`  (IDs collected from company page `a[href*="/question/"]`)

## Launch (CDP via puppeteer-core)
```js
const puppeteer = require('puppeteer-core');
const browser = await puppeteer.launch({
  executablePath: '/snap/chromium/current/usr/lib/chromium-browser/chrome',
  headless: 'new',
  args: ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage']
});
const page = await browser.newPage();
await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
```

## Extracting company fields (exact DOM — verified)
Fields live in `.cmp_details` as `.info` blocks: `<div class="label">Field</div><div class="text">value</div>`.
Extra fields (year/emp/reg) in `.extra_info`. Categories in `.cmp_details .tags a`.
```js
const data = await page.evaluate(() => {
  const field = (label) => {
    const lab = [...document.querySelectorAll('.cmp_details .info .label, .cmp_details .extra_info .info .label')]
      .find(l => l.textContent.replace(/\s+/g,' ').trim().toLowerCase().includes(label.toLowerCase()));
    if (!lab) return '';
    const info = lab.closest('.info') || lab.parentElement;
    const txt = (info.querySelector('.text') || info).textContent.replace(/\s+/g,' ').trim();
    return txt.replace(new RegExp('^'+label.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i'),'').trim();
  };
  return {
    name: (document.querySelector('#company_name')||document.querySelector('h1')).textContent.trim(),
    address: (document.querySelector('#company_address')||{}).textContent.replace(/\s+/g,' ').trim() || field('Address'),
    contact_number: field('Contact number'),
    mobile_phone: field('Mobile phone'),
    whatsapp: (document.querySelector('a[href*="wa.me"]')||{}).href || '',
    website: (document.querySelector('.text.weblinks a')||{}).href || '',
    establishment_year: field('Establishment year'),
    employees: field('Employees'),
    registration_code: field('Registration code'),
    company_description: ((document.querySelector('.text.desc')||{}).textContent||'').trim(),
    categories: [...document.querySelectorAll('.cmp_details .tags a')].map(a=>a.textContent.trim()),
    reviews: (document.querySelector('.reviews_count')||{}).textContent.replace(/\s+/g,' ').trim() || '',
    verified: !!document.querySelector('.vvv_verified'),
    premium: !!document.querySelector('.vvv_premium')
  };
});
```
Notes:
- `whatsapp` is a direct `wa.me/<number>` only when Yellosa exposes the number; otherwise a share-link `wa.me/?text=...`.
- `website` for non-premium listings is a Yellosa redirect `https://www.yellosa.co.za/redir/<id>?u=<urlencoded-real-domain>`. Decode `u=` param for the clean domain.
- Doctor/practitioner listings often omit mobile/website/emp/year — blank fields are real, not missed.

## Extracting Q&A (separate pages, client-side rendered)
1. On the company page, collect question IDs:
   ```js
   const qIds = [...new Set([...document.querySelectorAll('a[href*="/question/"]')]
     .map(a => (a.getAttribute('href').match(/\/question\/(\d+)/)||[])[1]).filter(Boolean))];
   ```
2. For each id, open `https://yellosa.co.za/question/<id>`, wait for `.content`, then:
   ```js
   const c = document.querySelector('.content').innerText.replace(/\s+/g,' ').trim();
   const seg = c.slice(c.indexOf('Question for:'));
   const qM = seg.match(/Posted on [\dA-Za-z, ]+?(.*?)(?:LISTING OWNER|PUBLIC USER|ANSWER)/i);
   const question = qM ? qM[1].replace(/\s+/g,' ').trim() : '';
   const aM = seg.match(/(?:LISTING OWNER|PUBLIC USER)[^\n]*?Posted on [\dA-Za-z, ]+?(.*?)ANSWER/i);
   const answer = aM ? aM[1].replace(/\s+/g,' ').trim() : '';
   ```
   - Unanswered questions have NO reply — `answer` is correctly empty.
   - Open each Q&A in its own `browser.newPage()`; close after read.

## Scaling past 10
- Location page yields ~20 links. For more, paginate: loop `?page=2`, `?page=3`, … until no new `/company/` links.
- Respect the site: small concurrency (1 tab per business), `networkidle2`, 1-2s gaps.

## Gotchas
- `headless: 'new'` required (old `true` is deprecated on Chromium 150).
- `--no-sandbox` is mandatory as root; without it Chromium refuses to start.
- If `browser_exec` cloud driver returns "no CDP endpoint", fall back to this local puppeteer-core path — it works headless on the VPS.
- `web_extract` returns 401/unauthorized for yellosa.co.za — don't use it; use CDP.
- Node scripts must run from the project dir (where `node_modules/puppeteer-core` lives) or require() fails.

## Output
Save to JSON (e.g. `pretoria_businesses.json`) with one object per business including a `qa` array of `{question, answer}`.
